package net.zoostar.crud.service.impl;

import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

@ContextConfiguration(locations = {"classpath:META-INF/applicationContext.xml"})
@ActiveProfiles({"test","standalone"})
public abstract class AbstractJunitServiceTest extends AbstractTransactionalJUnit4SpringContextTests {
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Rule
	public TestName testName = new TestName();
	
	@Before
	public void setUp() throws Exception {
		System.out.println();
		log.info("Executing Test: [{}]...", testName.getMethodName());
	}

}
