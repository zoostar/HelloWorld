package net.zoostar.crud.service.impl;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import net.zoostar.crud.model.entity.AppUser;
import net.zoostar.crud.service.UserManager;

public class UserManagerImplTest extends AbstractJunitServiceTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserManagerImplTest.class);
    
    private static final String USERNAME = "jd12345";
    private static final String USER_NAME1 = "John Doe";
    private static final String USER_NAME2 = "Jane Doe";
    private static final String PASSWORD = "Password123";
    
    protected UserManager userManager;
    
    @Autowired
    public void setUserManager(UserManager userManager) {
        LOGGER.debug("setUserManager({})", userManager);
        this.userManager = userManager;
    }

    @Test
    public void testUserCrudRepository() {
    	Assert.assertNotNull(userManager);

    	AppUser user = new AppUser(USERNAME.toUpperCase());
        user.setName(USER_NAME1);
        user.setPassword(PASSWORD);
        Assert.assertNull(user.getId());
        user = userManager.create(user);
        Assert.assertNotNull(user);
        Assert.assertNotNull(user.getId());
        String userId = user.getId();
        LOGGER.info("userId: {}", userId);
        
        user = userManager.retrieveByUsername(USERNAME);
        Assert.assertNotNull(user);
        Assert.assertNotNull(user.getId());
        Assert.assertEquals(user.getId(), userId);
        Assert.assertEquals(USER_NAME1, user.getName());
        
        user.setName(USER_NAME2);
        user = userManager.update(user);
        Assert.assertNotNull(user);
        Assert.assertNotNull(user.getId());
        Assert.assertEquals(user.getId(), userId);
        Assert.assertEquals(USER_NAME2, user.getName());
        
        userManager.delete(userId);
        user = userManager.retrieveByUsername(USERNAME);
        Assert.assertNull(user);
    }
}
