package net.zoostar.crud.service;

import net.zoostar.crud.model.entity.AppUser;

public interface UserManager extends PersistableCrudManager<AppUser, String> {
    AppUser retrieveByUsername(String username);
}
