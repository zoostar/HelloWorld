package net.zoostar.crud.service.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import net.zoostar.common.enrichment.Enricher;
import net.zoostar.crud.dao.UserRepository;
import net.zoostar.crud.model.entity.AppUser;
import net.zoostar.crud.service.UserManager;

@Service
public class UserManagerImpl extends AbstractPersistableCrudManager<AppUser, String> implements UserManager {

	protected UserRepository crudRepository;
    protected Enricher<String> upperCaseEnricher;
    protected Validator userValidator;

    @Autowired
    public void setCrudRepository(UserRepository crudRepository) {
    	this.crudRepository = crudRepository;
    }
    @Override
    protected CrudRepository<AppUser, String> getCrudRepository() {
    	return this.crudRepository;
    }
    
    @Autowired
    public void setUpperCaseEnricher(Enricher<String> upperCaseEnricher) {
        this.upperCaseEnricher = upperCaseEnricher;
    }

    @Autowired
    public void setUserValidator(Validator userValidator) {
        this.userValidator = userValidator;
    }

    
    @Override
    @Transactional(readOnly=true)
    public AppUser retrieveById(String id) {
        AppUser user = super.retrieveById(id);
        return user;
    }

    
    @Override
    @Transactional(readOnly=true)
    public AppUser retrieveByUsername(String username) {
        logger.info("retrieveByUsername(username:{})", username);
        AppUser user = crudRepository.findByUsername(upperCaseEnricher.enrich(username));
        user.eraseCredentials();
        return user;
    }
    
    
    @Override
    @Transactional(readOnly=false)
    public AppUser create(AppUser user) {
        user.setUsername(upperCaseEnricher.enrich(user.getUsername()));
        MapBindingResult errors = new MapBindingResult(new HashMap<>(), AppUser.class.getName());
        userValidator.validate(user, errors);
        
        if(!errors.hasErrors()) {
            return super.create(user);
        } else {
            for(ObjectError error : errors.getAllErrors()) {
                logger.error(error.getCode());
            }
        }
        
        return null;
    }

	@Override
	protected void preUpdate(AppUser user, AppUser userFromRepo) {
		userFromRepo.setName(user.getName());
	}
}
