package net.zoostar.crud.service.impl;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Persistable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import net.zoostar.crud.service.PersistableCrudManager;


@Transactional(readOnly=true)
public abstract class AbstractPersistableCrudManager<T extends Persistable<? extends Serializable>, ID extends Serializable>
implements PersistableCrudManager<T, ID> {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    protected abstract CrudRepository<T, ID> getCrudRepository();

//    @Override
    private T retrieveById(ID id) {
    	logger.info("retrieveById(id:{})", id);
        return getCrudRepository().findOne(id);
    }
    
    
    @Override
    @Transactional(readOnly=false)
    public T create(T entity) {
    	logger.info("create(entity:{})", entity);
		preCreate(entity);
		T entityFromRepo = getCrudRepository().save(entity);
		if(entityFromRepo != null) {
			postCreate(entity, entityFromRepo);
		}
        return entityFromRepo;
    }
	protected void preCreate(T entity) {
		logger.trace("preCreate(entity:{}) - Extending classes to implement.", entity);
	}
	protected void postCreate(T entity, T entityFromRepo) {
		logger.trace("postCreate(entity:{}, entityFromRepo:{}) - Extending classes to implement.", entity, entityFromRepo);
	}
    
	
    @Override
    @Transactional(readOnly=false)
    public void update(ID id, T entity) {
    	logger.info("update(entity:{})", entity);
    	T entityFromRepo = retrieveById(id);
    	preUpdate(entity, entityFromRepo);
    	entityFromRepo = getCrudRepository().save(entityFromRepo);
    	postUpdate(entity, entityFromRepo);
    }
	protected void preUpdate(T entity, T entityFromRepo) {
		logger.trace("preUpdate(entity:{}, entityFromRepo:{}) - Extending classes to implement.", entity, entityFromRepo);
	}
	protected void postUpdate(T entity, T entityFromRepo) {
		logger.trace("postUpdate(entity:{}, entityFromRepo:{}) - Extending classes to implement.", entity, entityFromRepo);
	}

	
    @Override
    @Transactional(readOnly=false)
    public void delete(ID id) {
        logger.info("delete(id:{})", id);
        T entityFromRepo = retrieveById(id);
        if(entityFromRepo != null) {
        	preDelete(entityFromRepo);
        }
    	getCrudRepository().delete(id);
    }
    protected void preDelete(T entityFromRepo) {
		logger.trace("preDelete(entityFromRepo:{}) - Extending classes to implement.", entityFromRepo);
    }

}
