package net.zoostar.crud.service;

import java.io.Serializable;

import org.springframework.data.domain.Persistable;

public interface PersistableCrudManager<T extends Persistable<? extends Serializable>, ID extends Serializable> {
//    T retrieveById(ID id);
    T create(T entity);
    void update(ID id, T entity);
    void delete(ID id);
}
