package net.zoostar.crud.exception;

public class EntityNotFoundException extends AbstractCrudException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2360608549518411023L;

	public EntityNotFoundException(String message) {
		super(message);
	}
}
