package net.zoostar.crud.model.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;
import org.springframework.security.core.CredentialsContainer;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="APP_USER", uniqueConstraints={
        @UniqueConstraint(columnNames={"USERNAME"})
    }
)
public class AppUser extends AbstractStringPersistableEntity
implements UserDetails, CredentialsContainer {

    /**
     * 
     */
    private static final long serialVersionUID = 4471971833125524648L;
    
    private String username;
    private String password;
    private boolean accountNonExpired = true;
    private boolean accountNonLocked = true;
    private boolean credentialsNonExpired = true;
    private boolean enabled = true;
    private String name;
    private Set<AppAuthority> authorities = new HashSet<>();

    protected AppUser() {
    	
    }
    
    public AppUser(String username) {
        if(username == null || StringUtils.isEmpty(username))
            throw new NullPointerException("Username cannot be null or empty!");
        this.username = username;
    }
    
    @Override
    @Column(name="USERNAME", length=50, nullable=false, unique=true)
    public String getUsername() {
        return this.username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    
    @Override
    @Column(name="PASSWORD", length=100, nullable=false)
    public String getPassword() {
        return this.password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    
    @Override
    @Column(name="ACCOUNT_NON_EXPIRED", nullable=false)
    @Type(type="yes_no")
    public boolean isAccountNonExpired() {
        return this.accountNonExpired;
    }
    public void setAccountNonExpired(boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }
    
    @Override
    @Column(name="ACCOUNT_NON_LOCKED", nullable=false)
    @Type(type="yes_no")
    public boolean isAccountNonLocked() {
        return this.accountNonLocked;
    }
    public void setAccountNonLocked(boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }
    
    @Override
    @Column(name="CREDENTIALS_NON_EXPIRED", nullable=false)
    @Type(type="yes_no")
    public boolean isCredentialsNonExpired() {
        return this.credentialsNonExpired;
    }
    public void setCredentialsNonExpired(boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }
    
    @Override
    @Column(name="ENABLED", nullable=false)
    @Type(type="yes_no")
    public boolean isEnabled() {
        return this.enabled;
    }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Column(name="NAME", length=50)
    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    @ManyToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL, targetEntity=AppAuthority.class)
    @JoinTable(name="USER_AUTHORITIES",
        joinColumns={@JoinColumn(name="USER_ID", referencedColumnName="ID")},
        inverseJoinColumns={@JoinColumn(name="AUTHORITY_ID", referencedColumnName="ID")}
    )
    @JsonIgnore
    @Override
    public Set<AppAuthority> getAuthorities() {
        return this.authorities;
    }
    public void addAuthority(AppAuthority authority) {
        logger.debug("Adding authority");
        authorities.add(authority);
        if(!authority.getUsers().contains(this)) {
            authority.addUser(this);
            logger.debug("Authority added.");
        }
    }
    protected void setAuthorities(Set<AppAuthority> authorities) {
        this.authorities = authorities;
    }
    
    @Override
	public String toString() {
		return "AppUser [username=" + username + ", accountNonExpired=" + accountNonExpired + ", accountNonLocked="
				+ accountNonLocked + ", credentialsNonExpired=" + credentialsNonExpired + ", enabled=" + enabled
				+ ", name=" + name + ", authorities=" + authorities + ", getId()=" + getId() + "]";
	}

    @Override
    public void eraseCredentials() {
        setPassword(null);
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((username == null) ? 0 : username.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AppUser other = (AppUser) obj;
        if (username == null) {
            if (other.username != null)
                return false;
        } else if (!username.equals(other.username))
            return false;
        return true;
    }
}
