package net.zoostar.crud.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import net.zoostar.crud.exception.EntityNotFoundException;
import net.zoostar.crud.model.entity.AppUser;
import net.zoostar.crud.service.PersistableCrudManager;
import net.zoostar.crud.service.UserManager;

@RestController
@RequestMapping(value = "/user")
public class UserRestController extends AbstractRestCrudController<AppUser, String> {

	public static final Class<AppUser> clazz = AppUser.class;

	private UserManager userManager;

	@Autowired
	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
	}
	protected UserManager getUserManager() {
		return this.userManager;
	}
	@Override
	protected PersistableCrudManager<AppUser, String> getPersistableCrudManager() {
		return getUserManager();
	}

	@RequestMapping(value = "/{username}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AppUser> getUserByUsername(@PathVariable("username") String username) {
		AppUser user;
		try {
			user = getUserManager().retrieveByUsername(username);
		} catch(NullPointerException e) {
			logger.error(e.getMessage(), e);
			throw new EntityNotFoundException("No user found with username: " + username);
		}

		return new ResponseEntity<>(user, HttpStatus.OK);
	}
}