package net.zoostar.crud.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import net.zoostar.crud.model.entity.AppUser;

@Repository
public interface UserRepository extends CrudRepository<AppUser, String> {
    AppUser findByUsername(String username);
}
