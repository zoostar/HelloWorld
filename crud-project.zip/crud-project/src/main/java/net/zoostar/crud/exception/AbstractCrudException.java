package net.zoostar.crud.exception;

public abstract class AbstractCrudException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -721481787803249824L;

	public AbstractCrudException(String message) {
		super(message);
	}

}
