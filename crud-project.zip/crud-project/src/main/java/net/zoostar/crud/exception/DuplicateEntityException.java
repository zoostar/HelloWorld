package net.zoostar.crud.exception;

public class DuplicateEntityException extends AbstractCrudException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2178085946708264713L;

	public DuplicateEntityException(String message) {
		super(message);
	}
}
