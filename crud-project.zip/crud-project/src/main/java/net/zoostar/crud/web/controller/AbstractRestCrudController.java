package net.zoostar.crud.web.controller;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Persistable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.UriComponentsBuilder;

import net.zoostar.crud.exception.DuplicateEntityException;
import net.zoostar.crud.service.PersistableCrudManager;

public abstract class AbstractRestCrudController<T extends Persistable<? extends Serializable>, ID extends Serializable> {

	protected final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	protected abstract PersistableCrudManager<T, ID> getPersistableCrudManager();

	
	//-------------------Create--------------------------------------------------------
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public ResponseEntity<T> createEntity(@RequestBody T entity, UriComponentsBuilder ucBuilder) {
		try {
			return new ResponseEntity<>(getPersistableCrudManager().create(entity), HttpStatus.CREATED);
		} catch(DataIntegrityViolationException e) {
			logger.error(e.getMessage(), e);
			throw new DuplicateEntityException("Entity already exists: " + entity);
		}
	}

	
	//------------------- Update--------------------------------------------------------
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public ResponseEntity<T> updateEntity(@PathVariable("id") ID id, @RequestBody T entity) {
		getPersistableCrudManager().update(id, entity);
		return new ResponseEntity<>(getPersistableCrudManager().retrieveById(id), HttpStatus.OK);
	}

	
	//------------------- Delete a User --------------------------------------------------------
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<T> deleteEntity(@PathVariable("id") ID id) {
		getPersistableCrudManager().delete(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
