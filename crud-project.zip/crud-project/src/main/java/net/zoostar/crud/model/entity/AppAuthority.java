package net.zoostar.crud.model.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="APP_AUTHORITY", uniqueConstraints={
        @UniqueConstraint(columnNames={"AUTHORITY"})
    }
)
public class AppAuthority extends AbstractStringPersistableEntity implements GrantedAuthority {
    
    /**
     * 
     */
    private static final long serialVersionUID = -3798900728960125929L;

    private String authority;
    private Set<AppUser> users = new HashSet<>();

    protected AppAuthority() {
        
    }
    
    public AppAuthority(String authority) {
        if(authority == null || StringUtils.isEmpty(authority))
            throw new NullPointerException("Authority name cannot be null or empty!");
        
        this.authority = authority;
    }
    
    @Override
    @Column(name="AUTHORITY", nullable=false, length=50, unique=true)
    public String getAuthority() {
        return this.authority;
    }
    protected void setAuthority(String authority) {
        this.authority = authority;
    }

    @JsonIgnore
    @ManyToMany(mappedBy="authorities", cascade=CascadeType.PERSIST)
    public Set<AppUser> getUsers() {
        return this.users;
    }
    public void addUser(AppUser user) {
        logger.debug("Adding user");
        this.users.add(user);
        if(!user.getAuthorities().contains(this)) {
            logger.debug("User added");
            user.addAuthority(this);
        }
    }
    protected void setUsers(Set<AppUser> users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((authority == null) ? 0 : authority.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AppAuthority other = (AppAuthority) obj;
        if (authority == null) {
            if (other.authority != null)
                return false;
        } else if (!authority.equals(other.authority))
            return false;
        return true;
    }
    
    @Override
    public String toString() {
        return "AppAuthority [authority=" + authority + "]";
    }

}
