package net.zoostar.crud.model.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Persistable;

@MappedSuperclass
public abstract class AbstractStringPersistableEntity implements Persistable<String> {

    /**
     * 
     */
    private static final long serialVersionUID = -1833433279014630013L;
    
    protected final transient Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private String id;
    
    protected AbstractStringPersistableEntity() {    }
    
    @Id
    @GeneratedValue(generator="system-uuid")
    @GenericGenerator(name="system-uuid", strategy="uuid2")
    @Column(name="ID", nullable=false, unique=true, columnDefinition="char(36)")
    @Override
    public String getId() {
        return id;
    }
    protected void setId(String id) {
        this.id = id;
    }

    @Override
    @Transient
    public boolean isNew() {
        return getId() == null;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AbstractStringPersistableEntity other = (AbstractStringPersistableEntity) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
