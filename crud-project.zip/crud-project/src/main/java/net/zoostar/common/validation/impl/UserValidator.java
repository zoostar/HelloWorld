package net.zoostar.common.validation.impl;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import net.zoostar.crud.model.entity.AppUser;

@Component(value="userValidator")
public class UserValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return AppUser.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        AppUser user = (AppUser)target;
        if(user.getUsername() == null || user.getUsername().length() != 7) {
            errors.rejectValue("username", "soeid has to be exactly 7 characters");
        }
    }

}
