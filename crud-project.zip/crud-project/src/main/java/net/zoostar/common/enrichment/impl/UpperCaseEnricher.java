package net.zoostar.common.enrichment.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import net.zoostar.common.enrichment.Enricher;

@Component
public class UpperCaseEnricher implements Enricher<String> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpperCaseEnricher.class);
    
    @Override
    public String enrich(String value) {
        LOGGER.info("Enriching value [{}] to upper case." , value);
        if(value != null)
            return value.toUpperCase();
        
        return null;
    }

}
