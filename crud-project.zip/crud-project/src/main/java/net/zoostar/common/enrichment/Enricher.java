package net.zoostar.common.enrichment;

@FunctionalInterface
public interface Enricher<T> {
    T enrich(T object);
}
